# API Integration Guide

This document explains how to integrate your backend services (LLM, OCR, and GAN) with the ADHD Student Support Web App.

## Overview

The app follows a 5-step process:

1. **Step 1**: User uploads text or image
2. **Step 2**: Text is sent to LLM for simplification
3. **Step 3**: Camera captures user's reaction
4. **Step 4**: Reaction image is sent to OCR for classification
5. **Step 5**: Simplified text + reaction class is sent to GAN for personalization

## Configuration

### Setup Environment Variables

1. Copy `.env.example` to `.env.local`:
   ```bash
   cp .env.example .env.local
   ```

2. Update the API URLs in `.env.local`:
   ```
   NEXT_PUBLIC_API_URL=http://your-backend-url:PORT
   ```

## API Endpoints

The app expects the following POST endpoints:

### 1. LLM Simplification - `/api/llm`

**Request:**
```json
{
  "content": "string",
  "contentType": "text" | "image"
}
```

**Response:**
```json
{
  "simplifiedText": "string",
  "success": true,
  "error": "string (optional)"
}
```

**Example Implementation (Node.js):**
```javascript
app.post('/api/llm', async (req, res) => {
  const { content, contentType } = req.body;
  
  try {
    // Send to your LLM service
    const simplifiedText = await yourLLMService.simplify(content, contentType);
    
    res.json({
      simplifiedText,
      success: true,
    });
  } catch (error) {
    res.json({
      success: false,
      error: error.message,
    });
  }
});
```

### 2. OCR - Real-time Video Frame Analysis (NEW)

#### 2a. Continuous Frame Analysis - `/api/ocr/video-frame` (NEW)

This endpoint is called continuously while the student reads. Each video frame is sent for analysis.

**Request:**
```json
{
  "frame": "base64-encoded-frame-string"
}
```

**Response:**
```json
{
  "currentClass": "normal" | "inattentive" | "hyperactive-impulsive" | "combined",
  "currentScore": 0-100,
  "averageScore": 0-100,
  "frameCount": 5,
  "confidence": 0-100,
  "success": true,
  "error": "string (optional)"
}
```

**Example Implementation (Node.js):**
```javascript
app.post('/api/ocr/video-frame', async (req, res) => {
  const { frame } = req.body;
  
  try {
    // Analyze the current frame
    const result = await yourOCRService.analyzeFrame(frame);
    
    res.json({
      currentClass: result.class,
      currentScore: result.score,
      averageScore: result.averageScore, // aggregate of all frames so far
      frameCount: result.totalFrames,
      confidence: result.confidence,
      success: true,
    });
  } catch (error) {
    res.json({
      success: false,
      error: error.message,
    });
  }
});
```

#### 2b. Finalize Video Analysis - `/api/ocr/finalize` (NEW)

Called when the student finishes reading to get the final reaction classification.

**Request:**
```json
{}
```

**Response:**
```json
{
  "reactionClass": "normal" | "inattentive" | "hyperactive-impulsive" | "combined",
  "reactionScore": 0-100,
  "confidence": 0-100,
  "success": true,
  "error": "string (optional)"
}
```

**Example Implementation:**
```javascript
app.post('/api/ocr/finalize', async (req, res) => {
  try {
    // Aggregate all frames analyzed and return final classification
    const finalResult = await yourOCRService.finalize();
    
    res.json({
      reactionClass: finalResult.class,
      reactionScore: finalResult.finalScore,
      confidence: finalResult.confidence,
      success: true,
    });
  } catch (error) {
    res.json({
      success: false,
      error: error.message,
    });
  }
});
```

---

### 3. OCR Classification (Legacy) - `/api/ocr`

For single image capture (if needed for backward compatibility).

**Request:**
```json
{
  "image": "base64-encoded-image-string"
}
```

**Response:**
```json
{
  "reactionClass": "normal" | "inattentive" | "hyperactive-impulsive" | "combined",
  "reactionScore": 0-100,
  "confidence": 0-100,
  "success": true,
  "error": "string (optional)"
}
```

**Example Implementation (Node.js):**
```javascript
app.post('/api/ocr', async (req, res) => {
  const { image } = req.body;
  
  try {
    // Send to your OCR service
    const result = await yourOCRService.classify(image);
    
    res.json({
      reactionClass: result.class,
      reactionScore: result.score,
      confidence: result.confidence,
      success: true,
    });
  } catch (error) {
    res.json({
      success: false,
      error: error.message,
    });
  }
});
```

### 4. GAN Personalization - `/api/gan`

**Request:**
```json
{
  "text": "simplified-text-string",
  "reactionClass": "normal" | "inattentive" | "hyperactive-impulsive" | "combined",
  "reactionScore": 0-100
}
```

**Response:**
```json
{
  "personalizedText": "string",
  "success": true,
  "error": "string (optional)"
}
```

**Example Implementation (Node.js):**
```javascript
app.post('/api/gan', async (req, res) => {
  const { text, reactionClass, reactionScore } = req.body;
  
  try {
    // Send to your GAN service
    const personalizedText = await yourGANService.personalize(
      text,
      reactionClass,
      reactionScore
    );
    
    res.json({
      personalizedText,
      success: true,
    });
  } catch (error) {
    res.json({
      success: false,
      error: error.message,
    });
  }
});
```

## Using Mock Data (Development)

The app comes with built-in mock functions for testing. To use them:

**In `services/api.ts`:**
```typescript
// Replace real API calls with mock versions
const response = await apiService.mockSimplifyContent(content);
const response = await apiService.mockClassifyReaction();
const response = await apiService.mockPersonalizeContent(simplifiedText);
```

## Integration Steps

1. **Create your backend API** with the three endpoints above
2. **Test locally** by running both frontend and backend on localhost
3. **Update `.env.local`** with your API URL
4. **Replace mock calls** in the steps with real API calls
5. **Test the full workflow** end-to-end

## Error Handling

The app handles errors gracefully:
- Shows user-friendly error messages
- Logs errors to console for debugging
- Allows users to retry failed operations

## Data Flow

```
User Input (Text/Image)
    ↓
LLM Simplification
    ↓
Display Simplified Text
    ↓
Camera Capture
    ↓
OCR Classification (gets reaction class)
    ↓
GAN Personalization (adapts text based on reaction)
    ↓
Display Final Result (with dynamic theming)
```

## CORS Configuration

Make sure your backend is configured to accept requests from your frontend domain:

```javascript
app.use(cors({
  origin: ['http://localhost:3000', 'your-frontend-domain.com'],
  credentials: true,
}));
```

## Testing Checklist

- [ ] LLM endpoint returns proper simplified text
- [ ] OCR endpoint correctly classifies reactions
- [ ] GAN endpoint personalizes text appropriately
- [ ] Error responses are handled gracefully
- [ ] All API responses match expected schemas
- [ ] CORS is properly configured

## Support

For issues or questions about the API integration:
1. Check the debug logs in the browser console (look for `[v0]` prefixed messages)
2. Verify your API endpoints are returning correct response formats
3. Ensure environment variables are set correctly
