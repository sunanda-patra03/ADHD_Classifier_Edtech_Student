# Continuous Video Streaming Update

## Overview

The app has been updated to use **continuous video streaming** instead of single image capture. The student's reaction is now analyzed in real-time as they read the simplified content, providing live feedback on their engagement level.

## What Changed

### Before (Single Image Capture)
- Student reads simplified text
- After 5 seconds, single image captured
- Image sent to OCR for classification
- Reaction class determined from single frame

### After (Continuous Video Streaming)
- Student reads simplified text
- Live camera feed displayed simultaneously
- Video frames captured every ~1 second
- **Each frame analyzed in real-time** by OCR
- Live metrics displayed: reaction class, confidence score, frame count, study duration
- Student controls when to finish by clicking "Done Reading"
- When finished, all frame data sent to `/api/ocr/finalize` for final classification
- Final classification used to personalize content

## UI Changes

### Step 2 - Study + Live Reaction (New Layout)

**Two-column layout:**

**Left Column:**
- Simplified text displayed (scrollable)
- Large, readable format for ADHD-friendly learning
- Full study content visible

**Right Column:**
- Live camera feed (video element)
- LIVE indicator (red pulsing dot)
- Real-time metrics:
  - Current reaction class (updates every ~1 second)
  - Confidence score (0-100% with progress bar)
  - Frames captured counter
  - Study time counter (seconds)

**Control:**
- "Back" button - return to input step
- "Done Reading" button - finalize analysis and proceed

## Backend Integration

### New Endpoints

#### 1. `/api/ocr/video-frame` (POST)
Called continuously (every ~1 second) while student reads.

**Request:**
```json
{
  "frame": "base64-encoded-video-frame"
}
```

**Response:**
```json
{
  "currentClass": "normal|inattentive|hyperactive-impulsive|combined",
  "currentScore": 75,
  "averageScore": 72,
  "frameCount": 5,
  "confidence": 85,
  "success": true
}
```

**Purpose:** Provide live feedback on current reaction and aggregate metrics.

#### 2. `/api/ocr/finalize` (POST)
Called once when student clicks "Done Reading" to get final classification.

**Request:**
```json
{}
```

**Response:**
```json
{
  "reactionClass": "normal|inattentive|hyperactive-impulsive|combined",
  "reactionScore": 73,
  "confidence": 88,
  "success": true
}
```

**Purpose:** Return final aggregated reaction classification from all frames analyzed during study session.

### Implementation Details

Your OCR backend needs to:

1. **Maintain state** for the current study session
   - Store all frame analyses
   - Calculate running average
   - Track frame count and confidence

2. **Handle `/api/ocr/video-frame`** endpoint
   - Accept video frame as base64
   - Analyze reaction in frame
   - Return current + aggregate metrics
   - Update session state

3. **Handle `/api/ocr/finalize`** endpoint
   - Process all accumulated frame data
   - Return final reaction classification
   - Clear/reset session state for next session

### Example Implementation Pattern

```javascript
// In-memory session tracking (for development)
let currentSession = {
  frames: [],
  analyses: [],
};

app.post('/api/ocr/video-frame', async (req, res) => {
  const { frame } = req.body;
  
  const analysis = await analyzeFrame(frame);
  currentSession.frames.push(frame);
  currentSession.analyses.push(analysis);
  
  const average = calculateAverage(currentSession.analyses);
  
  res.json({
    currentClass: analysis.class,
    currentScore: analysis.score,
    averageScore: average.score,
    frameCount: currentSession.frames.length,
    confidence: analysis.confidence,
    success: true,
  });
});

app.post('/api/ocr/finalize', async (req, res) => {
  const finalAnalysis = aggregateAnalyses(currentSession.analyses);
  
  const result = {
    reactionClass: finalAnalysis.class,
    reactionScore: finalAnalysis.score,
    confidence: finalAnalysis.confidence,
    success: true,
  };
  
  // Reset session for next study
  currentSession = { frames: [], analyses: [] };
  
  res.json(result);
});
```

## Frontend Flow

### Step 2 Component (`Step2Result.tsx`)

1. **Camera initialization:**
   - Requests camera permission (already done in Step 1)
   - Starts continuous frame capture every 1 second

2. **Real-time analysis loop:**
   - Each frame captured from video stream
   - Frame sent to `/api/ocr/video-frame`
   - Response received with live metrics
   - UI updated with new metrics (reaction class, score, frame count)

3. **Study completion:**
   - Student clicks "Done Reading" button
   - Continuous capture stops
   - `/api/ocr/finalize` called to get final classification
   - GAN called with final reaction class
   - Personalized content generated
   - Automatic transition to Step 3 (final result)

## State Management

The app tracks through `useStudy()` context:
- `simplifiedText` - from LLM (Step 1)
- `reactionImage` - last captured frame
- `reactionClass` - final classification (from `/api/ocr/finalize`)
- `reactionScore` - final score
- `personalizedText` - from GAN (Step 3)

## Configuration

### Video Capture Interval
- **Default:** 1 second (1000ms)
- **Location:** `Step2Result.tsx` - `startContinuousCapture(callback, 1000)`
- **Customize:** Adjust the `1000` parameter to change frequency

### Frame Quality
- **Default:** JPEG 0.9 quality
- **Location:** `useCamera.ts` - `toDataURL('image/jpeg', 0.9)`
- **Customize:** Adjust quality parameter (0-1) for bandwidth/quality trade-off

## Error Handling

- **Camera not available:** Error message shown, "Back" button to retry
- **Frame analysis fails:** Current frame skipped, analysis continues
- **Finalization fails:** Error shown, student can retry
- **Network issues:** Graceful handling with retry logic

## Accessibility & ADHD-Friendly Features

- **Large, readable text** on left for focus
- **Real-time feedback** keeps attention on metrics
- **No time pressure** - student controls duration
- **Visual engagement** with LIVE indicator and animated progress bar
- **Clear metrics** showing progress and current reaction
- **Pastel color scheme** reduces visual stress
- **Smooth animations** for ADHD engagement

## Testing

### Mock Mode (Development)
The app uses `mockAnalyzeVideoFrame()` and `mockFinalizeVideoAnalysis()` from `apiService` by default. These simulate:
- Random reaction class selection
- Random score generation (0-100)
- Variable frame counts
- Realistic timing delays

### Production Mode
Set `NEXT_PUBLIC_API_URL` in `.env.local` to your backend and the real endpoints will be called automatically.

## Performance Considerations

- **Frame encoding:** Base64 encoding adds ~33% overhead - consider binary transfer for optimization
- **Network bandwidth:** ~1-2 frames/second at 1280x720 quality can consume significant bandwidth
- **Processing delay:** Ensure OCR processing completes within 1 second window
- **UI updates:** React state updates from each frame analysis - memoization recommended for large apps

## Migration from Single Image Capture

If you were using the previous single image capture version:

1. **Remove countdown logic** - no longer needed
2. **Update `/api/ocr`** - can be deprecated or kept for backward compatibility
3. **Implement `/api/ocr/video-frame`** - main analysis endpoint
4. **Implement `/api/ocr/finalize`** - final classification endpoint
5. **Session state management** - maintain state across multiple frame analyses
6. **Client update:** Already done - `Step2Result.tsx` updated automatically
