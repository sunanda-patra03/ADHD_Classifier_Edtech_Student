'use client';

import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

interface FloatingElementsProps {
  step: number;
}

const elements = {
  1: ['✏️', '📝', '📸', '💭', '🌟'],
  2: ['✨', '💡', '🎯', '🚀', '⭐'],
  3: ['📷', '👀', '🎬', '📹', '✨'],
  4: ['⚙️', '🔄', '💫', '🌀', '✨'],
  5: ['🎉', '🏆', '⭐', '💫', '🌟'],
};

export function FloatingElements({ step }: FloatingElementsProps) {
  const [isClient, setIsClient] = useState(false);
  
  useEffect(() => {
    setIsClient(true);
  }, []);

  const stepElements = elements[step as keyof typeof elements] || elements[1];
  const positions = [
    { top: '10%', left: '5%' },
    { top: '15%', right: '8%' },
    { bottom: '20%', left: '10%' },
    { bottom: '15%', right: '5%' },
    { top: '50%', left: '2%' },
  ];

  if (!isClient) return null;

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {stepElements.map((element, index) => (
        <motion.div
          key={index}
          className="absolute text-4xl"
          style={positions[index]}
          animate={{
            y: [0, -30, 0],
            x: [0, Math.sin(index) * 20, 0],
            rotate: [0, 360],
            opacity: [0.2, 0.6, 0.2],
          }}
          transition={{
            duration: 4 + index,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          {element}
        </motion.div>
      ))}
    </div>
  );
}
