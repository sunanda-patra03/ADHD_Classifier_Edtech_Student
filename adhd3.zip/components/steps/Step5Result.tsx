'use client';

import { motion } from 'framer-motion';
import { useStudy, ReactionClass } from '@/context/StudyContext';
import { ConfettiTrigger } from '@/components/ConfettiTrigger';
import { Button } from '@/components/ui/button';
import { useEffect, useState } from 'react';

interface Step5ResultProps {
  onReset: () => void;
}

const themeConfig = {
  normal: {
    bg: 'from-green-100 to-emerald-50',
    border: 'border-green-400',
    header: 'text-green-800',
    message: 'bg-green-100 border-green-400 text-green-800',
    button: 'from-green-400 to-green-500 hover:from-green-500 hover:to-green-600',
    emoji: '😊',
    title: 'You\'re Focused & Ready!',
  },
  inattentive: {
    bg: 'from-amber-100 to-yellow-50',
    border: 'border-amber-400',
    header: 'text-amber-800',
    message: 'bg-amber-100 border-amber-400 text-amber-800',
    button: 'from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600',
    emoji: '🤔',
    title: 'Let\'s Keep Things Simple!',
  },
  'hyperactive-impulsive': {
    bg: 'from-red-100 to-rose-50',
    border: 'border-red-400',
    header: 'text-red-800',
    message: 'bg-red-100 border-red-400 text-red-800',
    button: 'from-red-400 to-red-500 hover:from-red-500 hover:to-red-600',
    emoji: '⚡',
    title: 'Ready for Action!',
  },
  combined: {
    bg: 'from-indigo-100 to-purple-50',
    border: 'border-indigo-400',
    header: 'text-indigo-800',
    message: 'bg-indigo-100 border-indigo-400 text-indigo-800',
    button: 'from-indigo-400 to-indigo-500 hover:from-indigo-500 hover:to-indigo-600',
    emoji: '🎯',
    title: 'Perfectly Balanced for You!',
  },
};

export function Step5Result({ onReset }: Step5ResultProps) {
  const { data, reset } = useStudy();
  const [showConfetti, setShowConfetti] = useState(false);

  // Placeholder GAN JSON response - customize styling based on reaction class
  const ganJsonResponse = {
    status: 'success',
    reactionClass: data.reactionClass || 'normal',
    adaptedText: data.personalizedText,
    confidence: data.reactionScore || 0.85,
    styleAdjustments: {
      fontSize: 
        data.reactionClass === 'inattentive' ? 'larger' : 
        data.reactionClass === 'hyperactive-impulsive' ? 'medium' : 
        'normal',
      spacing:
        data.reactionClass === 'inattentive' ? 'generous' :
        data.reactionClass === 'hyperactive-impulsive' ? 'compact' :
        'normal',
      complexity:
        data.reactionClass === 'inattentive' ? 'simplified' :
        data.reactionClass === 'hyperactive-impulsive' ? 'energetic' :
        'balanced',
    },
    timestamp: new Date().toISOString(),
  };

  const theme = themeConfig[data.reactionClass || 'normal'];

  useEffect(() => {
    // Trigger confetti on component mount
    const timer = setTimeout(() => {
      setShowConfetti(true);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const handleReset = () => {
    reset();
    onReset();
  };

  const reactionEmojis = {
    normal: ['😊', '🤗', '😌', '👍'],
    inattentive: ['🤔', '💭', '😐', '🧐'],
    'hyperactive-impulsive': ['⚡', '🎉', '🚀', '💥'],
    combined: ['🎯', '💪', '🌟', '✨'],
  };

  return (
    <>
      <ConfettiTrigger trigger={showConfetti} particleCount={100} spread={70} />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className={`min-h-screen flex items-center justify-center p-8 bg-gradient-to-br ${theme.bg}`}
      >
        <div className="w-full max-w-3xl">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -30, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="text-center mb-12"
          >
            <motion.span
              animate={{ rotate: [0, 10, -10, 0], scale: [1, 1.1, 1] }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-7xl block mb-4"
            >
              {theme.emoji}
            </motion.span>
            <h1 className={`text-5xl font-bold mb-4 ${theme.header}`}>
              {theme.title}
            </h1>
            <p className="text-xl text-gray-600">
              Here's your personalized content:
            </p>
          </motion.div>

          {/* Reaction Info */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className={`
              flex gap-8 p-6 rounded-2xl mb-10 border-3 ${theme.message}
            `}
          >
            <div>
              <p className="font-bold text-lg">Your Reaction:</p>
              <p className="text-base mt-1 capitalize font-semibold">
                {data.reactionClass?.replace('-', ' ') || 'Unknown'}
              </p>
            </div>
            <div className="border-l-2 border-current" />
            <div>
              <p className="font-bold text-lg">Confidence:</p>
              <p className="text-base mt-1 font-semibold">
                {data.reactionScore ? `${Math.round(data.reactionScore)}%` : 'N/A'}
              </p>
            </div>
          </motion.div>

          {/* Personalized Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className={`
              border-4 ${theme.border} rounded-3xl
              bg-white p-10 shadow-2xl mb-10
            `}
          >
            <div className="text-xl leading-relaxed text-gray-800 font-medium whitespace-pre-wrap break-words">
              {data.personalizedText}
            </div>
          </motion.div>

          {/* Interactive Floating Elements */}
          <div className="flex justify-center gap-4 mb-10">
            {reactionEmojis[data.reactionClass || 'normal'].map((emoji, index) => (
              <motion.div
                key={index}
                animate={{
                  y: [0, -20, 0],
                  rotate: [0, 10, -10, 0],
                }}
                transition={{
                  duration: 2,
                  delay: index * 0.1,
                  repeat: Infinity,
                }}
                className="text-4xl"
              >
                {emoji}
              </motion.div>
            ))}
          </div>

          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="flex gap-6"
          >
            <Button
              onClick={handleReset}
              className={`
                flex-1 py-4 text-xl font-bold rounded-2xl
                bg-gradient-to-r ${theme.button}
                text-white shadow-lg
              `}
            >
              Try Another! 🚀
            </Button>

            <Button
              onClick={() => {
                // Save or download functionality
                console.log('[v0] Saving result');
              }}
              className="
                flex-1 py-4 text-xl font-bold rounded-2xl
                bg-white border-3 border-gray-300
                hover:bg-gray-50 text-gray-800
              "
            >
              Save Result 💾
            </Button>
          </motion.div>

          {/* Footer Message */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="text-center mt-10 text-gray-600 font-semibold"
          >
            <p>✨ Great work! You've completed the process. ✨</p>
          </motion.div>
        </div>
      </motion.div>
    </>
  );
}
