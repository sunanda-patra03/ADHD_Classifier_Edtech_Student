'use client';

import { motion } from 'framer-motion';
import { useStudy } from '@/context/StudyContext';
import { useCamera } from '@/hooks/useCamera';
import { apiService } from '@/services/api';
import { Button } from '@/components/ui/button';
import { useEffect, useState } from 'react';

interface Step3CameraProps {
  onNext: () => void;
  onBack: () => void;
}

export function Step3Camera({ onNext, onBack }: Step3CameraProps) {
  const { data, setReactionImage, setReactionClass, setCurrentStep } = useStudy();
  const { videoRef, canvasRef, isActive, error, startCamera, stopCamera, captureImage } =
    useCamera();
  const [captured, setCaptured] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isClassifying, setIsClassifying] = useState(false);
  const [classifyError, setClassifyError] = useState<string | null>(null);

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, [startCamera, stopCamera]);

  const handleCapture = () => {
    console.log('[v0] Capturing reaction image');
    const imageData = captureImage();
    if (imageData) {
      setCapturedImage(imageData);
      setCaptured(true);
      setReactionImage(imageData);
    }
  };

  const handleClassify = async () => {
    if (!capturedImage) return;

    try {
      setClassifyError(null);
      setIsClassifying(true);
      console.log('[v0] Classifying reaction image');

      // Call OCR to classify reaction
      const response = await apiService.mockClassifyReaction();

      if (response.success) {
        setReactionClass(response.reactionClass, response.reactionScore);
        setCurrentStep(4);
        onNext();
      } else {
        setClassifyError('Failed to classify reaction');
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'An error occurred';
      setClassifyError(message);
      console.error('[v0] Error classifying reaction:', err);
    } finally {
      setIsClassifying(false);
    }
  };

  const handleRetake = () => {
    setCaptured(false);
    setCapturedImage(null);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="min-h-screen flex items-center justify-center p-8"
      style={{
        background: 'linear-gradient(135deg, rgba(253, 224, 71, 0.2), rgba(251, 191, 36, 0.2))',
      }}
    >
      <div className="w-full max-w-2xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold text-gray-800 mb-4">
            📷 Show Your Face!
          </h1>
          <p className="text-xl text-gray-600">
            Let's capture how you feel about this content
          </p>
        </motion.div>

        {/* Camera Section */}
        {!captured ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            {/* Camera Feed */}
            <div className="relative rounded-3xl overflow-hidden shadow-2xl bg-black">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full h-auto"
                style={{ aspectRatio: '16/9' }}
              />

              {/* Camera Status Indicator */}
              {isActive && (
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="
                    absolute top-4 right-4 w-4 h-4
                    bg-red-500 rounded-full shadow-lg
                  "
                />
              )}
            </div>

            {/* Error Message */}
            {error && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="
                  p-4 bg-red-100 border-3 border-red-400
                  rounded-lg text-red-700 font-semibold text-center
                "
              >
                {error}
              </motion.div>
            )}

            {/* Instructions */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="
                bg-yellow-100 border-3 border-yellow-400 rounded-2xl p-6
              "
            >
              <p className="text-lg text-yellow-800 font-semibold text-center">
                ✨ Look at your screen naturally - be yourself!
              </p>
            </motion.div>

            {/* Capture Button */}
            <Button
              onClick={handleCapture}
              disabled={!isActive}
              className="
                w-full py-4 text-xl font-bold rounded-2xl
                bg-gradient-to-r from-yellow-400 to-yellow-500
                hover:from-yellow-500 hover:to-yellow-600
                text-white disabled:opacity-50 disabled:cursor-not-allowed
                shadow-lg
              "
            >
              📸 Capture My Face!
            </Button>
          </motion.div>
        ) : (
          /* Captured Image Preview */
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            <div className="rounded-3xl overflow-hidden shadow-2xl">
              <img
                src={capturedImage}
                alt="Captured reaction"
                className="w-full h-auto"
                style={{ aspectRatio: '16/9', objectFit: 'cover' }}
              />
            </div>

            {/* Confirmation Message */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="
                bg-green-100 border-3 border-green-400 rounded-2xl p-6
              "
            >
              <p className="text-lg text-green-800 font-semibold text-center">
                ✅ Great shot! Now let's analyze your reaction...
              </p>
            </motion.div>

            {classifyError && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="
                  p-4 bg-red-100 border-3 border-red-400
                  rounded-lg text-red-700 font-semibold text-center
                "
              >
                {classifyError}
              </motion.div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-6">
              <Button
                onClick={handleRetake}
                disabled={isClassifying}
                className="
                  flex-1 py-4 text-lg font-bold rounded-2xl
                  bg-white border-3 border-gray-300
                  hover:bg-gray-50 text-gray-800
                  disabled:opacity-50
                "
              >
                ← Retake
              </Button>

              <Button
                onClick={handleClassify}
                disabled={isClassifying}
                className="
                  flex-1 py-4 text-lg font-bold rounded-2xl
                  bg-gradient-to-r from-yellow-400 to-yellow-500
                  hover:from-yellow-500 hover:to-yellow-600
                  text-white disabled:opacity-50
                  shadow-lg
                "
              >
                {isClassifying ? 'Analyzing...' : 'Analyze My Reaction! 🎯'}
              </Button>
            </div>
          </motion.div>
        )}

        {/* Back Button */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          onClick={onBack}
          className="mt-6 text-yellow-600 font-semibold hover:underline"
        >
          ← Back
        </motion.button>
      </div>
    </motion.div>
  );
}
