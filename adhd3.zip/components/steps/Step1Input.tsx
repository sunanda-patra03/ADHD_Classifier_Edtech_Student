'use client';

import { motion } from 'framer-motion';
import { useState, useRef } from 'react';
import { useStudy } from '@/context/StudyContext';
import { apiService } from '@/services/api';
import { Button } from '@/components/ui/button';

interface Step1InputProps {
  onNext: () => void;
}

export function Step1Input({ onNext }: Step1InputProps) {
  const { setOriginalContent, setSimplifiedText, setCurrentStep } = useStudy();
  const [inputMode, setInputMode] = useState<'text' | 'image' | null>(null);
  const [textValue, setTextValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [cameraPermissionAsked, setCameraPermissionAsked] = useState(false);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setTextValue(e.target.value);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      setImagePreview(result);
    };
    reader.readAsDataURL(file);
  };

  const requestCameraPermission = async () => {
    try {
      console.log('[v0] Requesting camera permission');
      await navigator.mediaDevices.getUserMedia({ video: true });
      setCameraPermissionAsked(true);
      console.log('[v0] Camera permission granted');
      return true;
    } catch (err) {
      console.log('[v0] Camera permission denied:', err);
      setError('Camera access is required to capture your reaction. Please enable camera access in your browser settings.');
      return false;
    }
  };

  const handleSubmit = async () => {
    try {
      setError(null);
      setIsLoading(true);

      // Request camera permission first if not already asked
      if (!cameraPermissionAsked) {
        console.log('[v0] Step 1: Requesting camera permission before submit');
        const permissionGranted = await requestCameraPermission();
        if (!permissionGranted) {
          setIsLoading(false);
          return;
        }
      }

      console.log('[v0] Step 1: Submitting content');

      let content = '';
      let contentType: 'text' | 'image' = 'text';

      if (inputMode === 'text' && textValue.trim()) {
        content = textValue;
        contentType = 'text';
      } else if (inputMode === 'image' && imagePreview) {
        content = imagePreview;
        contentType = 'image';
      } else {
        setError('Please provide text or upload an image');
        setIsLoading(false);
        return;
      }

      // Store original content
      setOriginalContent(content, contentType);

      // Call LLM to simplify
      console.log('[v0] Calling LLM to simplify content');
      const response = await apiService.mockSimplifyContent(content);

      if (response.success) {
        setSimplifiedText(response.simplifiedText);
        setCurrentStep(2);
        onNext();
      } else {
        setError(response.error || 'Failed to simplify content');
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'An error occurred';
      setError(message);
      console.error('[v0] Error in Step 1:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="min-h-screen flex items-center justify-center p-8"
      style={{
        background: 'linear-gradient(135deg, rgba(251, 191, 180, 0.2), rgba(244, 114, 182, 0.2))',
      }}
    >
      <div className="w-full max-w-2xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold text-gray-800 mb-4">
            Let's Get Started! 🚀
          </h1>
          <p className="text-xl text-gray-600">
            Upload an image or paste text you'd like to understand better
          </p>
        </motion.div>

        {/* Input Mode Selection */}
        {inputMode === null ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-2 gap-6 mb-8"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setInputMode('text')}
              className="
                p-8 rounded-3xl bg-gradient-to-br from-pink-300 to-pink-400
                text-white font-bold text-2xl shadow-lg
                hover:shadow-xl transition-all duration-300
                flex flex-col items-center gap-4
              "
            >
              <span className="text-5xl">📝</span>
              <span>Text Input</span>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setInputMode('image')}
              className="
                p-8 rounded-3xl bg-gradient-to-br from-blue-300 to-blue-400
                text-white font-bold text-2xl shadow-lg
                hover:shadow-xl transition-all duration-300
                flex flex-col items-center gap-4
              "
            >
              <span className="text-5xl">📸</span>
              <span>Upload Image</span>
            </motion.button>
          </motion.div>
        ) : null}

        {/* Text Input Mode */}
        {inputMode === 'text' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <motion.button
              whileHover={{ scale: 1.02 }}
              onClick={() => {
                setInputMode(null);
                setTextValue('');
              }}
              className="text-pink-600 font-semibold hover:underline mb-4"
            >
              ← Back
            </motion.button>

            <textarea
              value={textValue}
              onChange={handleTextChange}
              placeholder="Paste your text here... Make it as long or as short as you want!"
              className="
                w-full h-64 p-6 rounded-2xl border-3 border-pink-300
                text-lg font-medium resize-none focus:outline-none
                focus:ring-4 focus:ring-pink-400 bg-white
                placeholder:text-gray-400
              "
            />

            {error && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="p-4 bg-red-100 border-2 border-red-400 rounded-lg text-red-700 font-semibold"
              >
                {error}
              </motion.div>
            )}

            <Button
              onClick={handleSubmit}
              disabled={!textValue.trim() || isLoading}
              className="
                w-full py-4 text-xl font-bold rounded-2xl
                bg-gradient-to-r from-pink-400 to-pink-500
                hover:from-pink-500 hover:to-pink-600
                text-white disabled:opacity-50 disabled:cursor-not-allowed
              "
            >
              {isLoading ? 'Simplifying...' : 'Let\'s Simplify This! ✨'}
            </Button>
          </motion.div>
        )}

        {/* Image Upload Mode */}
        {inputMode === 'image' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <motion.button
              whileHover={{ scale: 1.02 }}
              onClick={() => {
                setInputMode(null);
                setImagePreview(null);
              }}
              className="text-blue-600 font-semibold hover:underline mb-4"
            >
              ← Back
            </motion.button>

            <div
              onClick={() => fileInputRef.current?.click()}
              className="
                w-full h-64 border-4 border-dashed border-blue-300 rounded-2xl
                flex items-center justify-center cursor-pointer
                hover:bg-blue-50 transition-colors duration-300
                bg-blue-100/50
              "
            >
              {imagePreview ? (
                <img
                  src={imagePreview}
                  alt="Preview"
                  className="max-h-60 max-w-full rounded-lg"
                />
              ) : (
                <div className="text-center">
                  <span className="text-6xl block mb-4">📷</span>
                  <p className="text-xl font-semibold text-blue-600">
                    Click or drag image here
                  </p>
                </div>
              )}
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
            />

            {error && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="p-4 bg-red-100 border-2 border-red-400 rounded-lg text-red-700 font-semibold"
              >
                {error}
              </motion.div>
            )}

            <Button
              onClick={handleSubmit}
              disabled={!imagePreview || isLoading}
              className="
                w-full py-4 text-xl font-bold rounded-2xl
                bg-gradient-to-r from-blue-400 to-blue-500
                hover:from-blue-500 hover:to-blue-600
                text-white disabled:opacity-50 disabled:cursor-not-allowed
              "
            >
              {isLoading ? 'Simplifying...' : 'Let\'s Simplify This! ✨'}
            </Button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
