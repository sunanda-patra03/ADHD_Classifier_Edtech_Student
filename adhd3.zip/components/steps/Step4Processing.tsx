'use client';

import { motion } from 'framer-motion';
import { useStudy } from '@/context/StudyContext';
import { apiService } from '@/services/api';
import { useEffect, useState } from 'react';

interface Step4ProcessingProps {
  onNext: () => void;
}

export function Step4Processing({ onNext }: Step4ProcessingProps) {
  const { data, setPersonalizedText, setCurrentStep } = useStudy();
  const [isProcessing, setIsProcessing] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const processContent = async () => {
      try {
        console.log('[v0] Processing: Calling GAN to personalize content');
        setError(null);

        const response = await apiService.mockPersonalizeContent(data.simplifiedText);

        if (response.success) {
          setPersonalizedText(response.personalizedText);
          
          // Add delay for visual effect
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          setCurrentStep(5);
          onNext();
        } else {
          setError(response.error || 'Failed to personalize content');
          setIsProcessing(false);
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : 'An error occurred';
        setError(message);
        console.error('[v0] Error in processing:', err);
        setIsProcessing(false);
      }
    };

    processContent();
  }, [data.simplifiedText, setPersonalizedText, setCurrentStep, onNext]);

  const processingSteps = [
    { text: 'Analyzing your response', emoji: '🧠', delay: 0 },
    { text: 'Understanding your style', emoji: '🎨', delay: 0.5 },
    { text: 'Personalizing content', emoji: '✨', delay: 1 },
    { text: 'Almost there...', emoji: '⚡', delay: 1.5 },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="min-h-screen flex items-center justify-center p-8"
      style={{
        background: 'linear-gradient(135deg, rgba(196, 181, 253, 0.2), rgba(167, 139, 250, 0.2))',
      }}
    >
      <div className="w-full max-w-2xl">
        {/* Main Processing Animation */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl font-bold text-gray-800 mb-4">
            ⚙️ Working Some Magic!
          </h1>
          <p className="text-xl text-gray-600">
            Customizing your content just for you...
          </p>
        </motion.div>

        {/* Loading Animation */}
        <motion.div
          className="flex justify-center mb-16"
          animate={{ rotate: 360 }}
          transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
        >
          <div className="
            w-32 h-32 rounded-full border-8 border-purple-200
            border-t-purple-500 border-r-purple-500 shadow-2xl
          " />
        </motion.div>

        {/* Processing Steps */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="space-y-6 mb-16"
        >
          {processingSteps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: step.delay + 0.3 }}
              className="
                flex items-center gap-4 p-6 rounded-2xl
                bg-purple-100 border-3 border-purple-300
                backdrop-blur-sm
              "
            >
              <motion.span
                animate={{ scale: [1, 1.3, 1] }}
                transition={{
                  duration: 0.8,
                  repeat: Infinity,
                  delay: step.delay,
                }}
                className="text-3xl"
              >
                {step.emoji}
              </motion.span>
              <span className="text-lg font-bold text-purple-800">
                {step.text}
              </span>
              <motion.div
                animate={{ width: ['0%', '100%'] }}
                transition={{
                  duration: 2,
                  delay: step.delay + 0.3,
                  ease: 'easeInOut',
                }}
                className="ml-auto h-2 bg-purple-400 rounded-full w-24"
              />
            </motion.div>
          ))}
        </motion.div>

        {/* Error State */}
        {error && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="
              p-6 bg-red-100 border-3 border-red-400
              rounded-2xl text-red-700 font-semibold text-center
            "
          >
            {error}
          </motion.div>
        )}

        {/* Floating Elements */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden">
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute text-4xl"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [0, -100, 0],
                opacity: [0.1, 0.5, 0.1],
              }}
              transition={{
                duration: 3 + i,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            >
              {['✨', '🌟', '💫', '⭐', '✨'][i]}
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
