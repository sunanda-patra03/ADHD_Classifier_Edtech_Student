'use client';

import { motion } from 'framer-motion';
import { useStudy } from '@/context/StudyContext';
import { useCamera } from '@/hooks/useCamera';
import { apiService } from '@/services/api';
import { Button } from '@/components/ui/button';
import { useEffect, useState, useRef } from 'react';

interface Step2ResultProps {
  onNext: () => void;
  onBack: () => void;
}

export function Step2Result({ onNext, onBack }: Step2ResultProps) {
  const { data, setReactionImage, setReactionClass, setPersonalizedText, setCurrentStep } = useStudy();
  const { videoRef, canvasRef, isActive, error: cameraError, startCamera, stopCamera, startContinuousCapture, stopContinuousCapture, captureImage } = useCamera();
  const [isStreaming, setIsStreaming] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingMessage, setProcessingMessage] = useState('');
  const [reactionScore, setReactionScore] = useState(0);
  const [reactionClass, setReactionClassState] = useState<string>('normal');
  const [frameCount, setFrameCount] = useState(0);
  const [studyDuration, setStudyDuration] = useState(0);
  const studyTimerRef = useRef<NodeJS.Timeout | null>(null);
  const videoVisibleRef = useRef(true);

  // Start camera and streaming on mount
  useEffect(() => {
    const initCamera = async () => {
      console.log('[v0] Step 2: Initializing continuous video streaming');
      await startCamera();
      
      // Start continuous frame capture
      startContinuousCapture(async (frameData) => {
        console.log('[v0] Processing video frame');
        
        try {
          const result = await apiService.mockAnalyzeVideoFrame();
          
          setFrameCount(prev => prev + 1);
          setReactionScore(result.averageScore);
          setReactionClassState(result.currentClass);
          
          console.log('[v0] Frame analysis:', {
            class: result.currentClass,
            score: result.averageScore,
            frames: result.frameCount,
          });
        } catch (err) {
          console.error('[v0] Error analyzing frame:', err);
        }
      }, 1000); // Capture every 1 second
      
      setIsStreaming(true);
    };

    initCamera();

    return () => {
      stopContinuousCapture();
      stopCamera();
    };
  }, [startCamera, stopCamera, startContinuousCapture, stopContinuousCapture]);

  // Track study duration
  useEffect(() => {
    if (isStreaming && !isProcessing) {
      studyTimerRef.current = setInterval(() => {
        setStudyDuration(prev => prev + 1);
      }, 1000);
    }

    return () => {
      if (studyTimerRef.current) {
        clearInterval(studyTimerRef.current);
      }
    };
  }, [isStreaming, isProcessing]);

  const handleFinishStudy = async () => {
    try {
      console.log('[v0] Finishing study session - finalizing video analysis');
      stopContinuousCapture();
      setIsProcessing(true);
      setProcessingMessage('Analyzing your study session...');

      // Finalize the video analysis to get final reaction class
      const finalResult = await apiService.mockFinalizeVideoAnalysis();
      
      console.log('[v0] Final reaction analysis:', finalResult);
      
      setReactionClass(finalResult.reactionClass, finalResult.reactionScore);
      setProcessingMessage('Personalizing content for you...');

      // Get the last captured frame as reaction image
      const reactionImage = captureImage();
      if (reactionImage) {
        setReactionImage(reactionImage);
      }

      // Call GAN to personalize content
      const ganResponse = await apiService.mockPersonalizeContent(data.simplifiedText, finalResult.reactionClass);
      
      if (ganResponse.success) {
        console.log('[v0] GAN personalization received');
        setPersonalizedText(ganResponse.personalizedText);
        setIsProcessing(false);

        // Move to final result step
        setTimeout(() => {
          console.log('[v0] Moving to final result step');
          setCurrentStep(3);
          onNext();
        }, 2000);
      }
    } catch (err) {
      console.error('[v0] Error finishing study:', err);
      setProcessingMessage('Error processing your session. Please try again.');
      setIsProcessing(false);
    }
  };

  if (cameraError) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="min-h-screen flex items-center justify-center p-8 bg-red-50"
      >
        <div className="max-w-md text-center">
          <h2 className="text-3xl font-bold text-red-800 mb-4">Camera Error</h2>
          <p className="text-lg text-red-700 mb-6">{cameraError}</p>
          <Button onClick={onBack} className="bg-red-600 text-white hover:bg-red-700">
            Go Back
          </Button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="min-h-screen flex items-center justify-center p-8"
      style={{
        background: 'linear-gradient(135deg, rgba(147, 197, 253, 0.2), rgba(96, 165, 250, 0.2))',
      }}
    >
      <div className="w-full max-w-6xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-center mb-8"
        >
          <h1 className="text-5xl font-bold text-gray-800 mb-4">
            ✨ Study Time!
          </h1>
          <p className="text-xl text-gray-600">
            Read this while we watch your reaction in real-time...
          </p>
        </motion.div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Simplified Text - Left/Full */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="
              lg:col-span-2
              bg-gradient-to-br from-blue-100 to-blue-50
              border-4 border-blue-300 rounded-3xl
              p-8 shadow-2xl
            "
          >
            <div className="
              text-xl leading-relaxed text-gray-800
              font-medium whitespace-pre-wrap break-words
              max-h-96 overflow-y-auto
            ">
              {data.simplifiedText}
            </div>
          </motion.div>

          {/* Live Camera Feed - Right */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="
              bg-gradient-to-br from-yellow-100 to-yellow-50
              border-4 border-yellow-300 rounded-3xl
              p-6 shadow-2xl
              flex flex-col items-center justify-center
            "
          >
            <div className="w-full aspect-square bg-black rounded-2xl overflow-hidden relative mb-4">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
              
              {/* Hidden canvas for frame capture */}
              <canvas ref={canvasRef} className="hidden" />
              
              {/* Live Indicator */}
              {isStreaming && !isProcessing && (
                <motion.div
                  animate={{ opacity: [1, 0.6] }}
                  transition={{ duration: 1, repeat: Infinity }}
                  className="absolute top-3 right-3 flex items-center gap-2 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold"
                >
                  <span className="w-2 h-2 bg-white rounded-full"></span>
                  LIVE
                </motion.div>
              )}
            </div>

            {/* Reaction Stats */}
            <motion.div
              key={frameCount}
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              className="w-full space-y-2 text-center"
            >
              <div className="text-sm text-gray-700">
                <p className="font-semibold">Frames Captured: {frameCount}</p>
                <p className="font-semibold">Study Time: {studyDuration}s</p>
              </div>
              
              <div className="bg-white rounded-xl p-3 border-2 border-yellow-300">
                <p className="text-xs text-gray-600 mb-1">Current Reaction</p>
                <p className="text-lg font-bold text-yellow-700 capitalize">{reactionClass}</p>
                <div className="mt-2 bg-gray-200 rounded-full h-2 overflow-hidden">
                  <motion.div
                    animate={{ width: `${reactionScore}%` }}
                    transition={{ duration: 0.5 }}
                    className="h-full bg-yellow-500"
                  />
                </div>
                <p className="text-xs text-gray-600 mt-1">{Math.round(reactionScore)}%</p>
              </div>
            </motion.div>
          </motion.div>
        </div>

        {/* Processing State */}
        {isProcessing && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="
              bg-gradient-to-br from-purple-100 to-purple-50
              border-4 border-purple-300 rounded-3xl
              p-10 text-center mb-8
            "
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity }}
              className="inline-block mb-4"
            >
              <span className="text-5xl">⚙️</span>
            </motion.div>
            <p className="text-2xl font-bold text-purple-800 mb-2">
              {processingMessage}
            </p>
            <p className="text-purple-700">
              Analyzing your {studyDuration} seconds of study data...
            </p>
          </motion.div>
        )}

        {/* Action Buttons */}
        {!isProcessing && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex gap-6"
          >
            <Button
              onClick={onBack}
              disabled={isProcessing}
              className="
                flex-1 py-4 text-lg font-bold rounded-2xl
                bg-white border-3 border-gray-300
                hover:bg-gray-50 disabled:opacity-50
                text-gray-800
              "
            >
              ← Back
            </Button>

            <Button
              onClick={handleFinishStudy}
              disabled={isProcessing || frameCount < 1}
              className="
                flex-1 py-4 text-lg font-bold rounded-2xl
                bg-gradient-to-r from-blue-400 to-blue-500
                hover:from-blue-500 hover:to-blue-600
                text-white shadow-lg disabled:opacity-50
              "
            >
              Done Reading ✓
            </Button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
