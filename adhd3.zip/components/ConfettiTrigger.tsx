'use client';

import { useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';

interface ConfettiTriggerProps {
  trigger: boolean;
  particleCount?: number;
  spread?: number;
}

export function ConfettiTrigger({
  trigger,
  particleCount = 100,
  spread = 70,
}: ConfettiTriggerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (trigger && canvasRef.current) {
      // Configure canvas for confetti
      const canvas = canvasRef.current;
      const rect = canvas.getBoundingClientRect();
      
      confetti({
        particleCount,
        spread,
        origin: { x: 0.5, y: 0.5 },
        colors: ['#fbbf24', '#f87171', '#60a5fa', '#a78bfa', '#34d399'],
      });

      // Also fire from corners for extra effect
      setTimeout(() => {
        confetti({
          particleCount: Math.floor(particleCount / 2),
          spread: 90,
          origin: { x: 0.1, y: 0.3 },
          colors: ['#fbbf24', '#f87171', '#60a5fa'],
        });

        confetti({
          particleCount: Math.floor(particleCount / 2),
          spread: 90,
          origin: { x: 0.9, y: 0.3 },
          colors: ['#34d399', '#a78bfa', '#f87171'],
        });
      }, 100);
    }
  }, [trigger, particleCount, spread]);

  return (
    <canvas
      ref={canvasRef}
      id="confetti-canvas"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
        zIndex: 9999,
      }}
    />
  );
}
