'use client';

import { motion } from 'framer-motion';

interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
}

export function ProgressBar({ currentStep, totalSteps }: ProgressBarProps) {
  const progress = (currentStep / totalSteps) * 100;

  const steps = Array.from({ length: totalSteps }, (_, i) => i + 1);
  
  const stepColors = [
    'from-pink-400 to-pink-500',
    'from-blue-400 to-blue-500',
    'from-yellow-300 to-yellow-400',
    'from-purple-400 to-purple-500',
    'from-green-400 to-green-500',
  ];

  return (
    <div className="w-full px-6 py-4">
      {/* Progress line */}
      <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden mb-6">
        <motion.div
          className="h-full bg-gradient-to-r from-pink-400 via-blue-400 to-purple-400"
          initial={{ width: '0%' }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
        />
      </div>

      {/* Step indicators */}
      <div className="flex justify-between items-center">
        {steps.map((step) => (
          <motion.div
            key={step}
            className="flex flex-col items-center"
            initial={{ scale: 0.8, opacity: 0.5 }}
            animate={{
              scale: step === currentStep ? 1.2 : 1,
              opacity: step <= currentStep ? 1 : 0.5,
            }}
            transition={{ duration: 0.3 }}
          >
            <div
              className={`
                w-12 h-12 rounded-full flex items-center justify-center
                font-bold text-lg transition-all duration-300
                ${step < currentStep
                  ? 'bg-green-400 text-white'
                  : step === currentStep
                  ? `bg-gradient-to-br ${stepColors[step - 1]} text-white shadow-lg`
                  : 'bg-gray-200 text-gray-500'
                }
              `}
            >
              {step < currentStep ? '✓' : step}
            </div>
            <span className="text-xs mt-2 font-medium text-gray-600">
              Step {step}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
