'use client';

import { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { useStudy } from '@/context/StudyContext';
import { ProgressBar } from '@/components/ProgressBar';
import { FloatingElements } from '@/components/FloatingElements';
import { Step1Input } from '@/components/steps/Step1Input';
import { Step2Result } from '@/components/steps/Step2Result';
import { Step5Result } from '@/components/steps/Step5Result';

export default function Home() {
  const { data, setCurrentStep } = useStudy();

  const handleNextStep = () => {
    console.log('[v0] Moving to next step:', data.currentStep + 1);
  };

  const handlePreviousStep = () => {
    if (data.currentStep > 1) {
      setCurrentStep(data.currentStep - 1);
      console.log('[v0] Moving to previous step:', data.currentStep - 1);
    }
  };

  const handleReset = () => {
    setCurrentStep(1);
    console.log('[v0] Resetting to step 1');
  };

  return (
    <main className="relative min-h-screen overflow-hidden">
      {/* Floating background elements */}
      <FloatingElements step={data.currentStep} />

      {/* Progress bar - hide on final result */}
      {data.currentStep < 3 && (
        <ProgressBar currentStep={data.currentStep} totalSteps={3} />
      )}

      {/* Step content with smooth transitions */}
      <AnimatePresence mode="wait">
        {data.currentStep === 1 && (
          <Step1Input
            key="step-1"
            onNext={handleNextStep}
          />
        )}

        {data.currentStep === 2 && (
          <Step2Result
            key="step-2"
            onNext={handleNextStep}
            onBack={handlePreviousStep}
          />
        )}

        {data.currentStep === 3 && (
          <Step5Result
            key="step-3"
            onReset={handleReset}
          />
        )}
      </AnimatePresence>
    </main>
  );
}
