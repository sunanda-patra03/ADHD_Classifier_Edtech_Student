# Quick Start Guide - ADHD Student Support App

## What's Changed from Original Plan

✅ **Reduced from 5 steps to 3 steps** - Streamlined workflow
✅ **Camera capture is automatic** - No manual button clicks, happens during reading
✅ **Simultaneous study + capture** - Student reads simplified text while camera captures reaction
✅ **Placeholder GAN JSON ready** - Dynamic theming based on reaction classification

---

## Running the App

### 1. Start the dev server
```bash
npm run dev
# or
pnpm dev
```

The app will start at `http://localhost:3000`

### 2. Test the current flow
1. **Step 1 (Input)**: Upload sample text or image
   - Request for camera access will appear
   - Approve to continue

2. **Step 2 (Study + Auto-Capture)**: 
   - Read simplified content
   - 5-second countdown appears (yellow badge)
   - Camera automatically captures at 0 seconds
   - "Analyzing reaction..." → "Personalizing content..."
   - Auto-transitions to Step 3

3. **Step 3 (Result)**:
   - Personalized content displayed with dynamic theming
   - Theme colors change based on reaction class
   - Confetti celebration animation
   - "Try Another Topic" button resets workflow

---

## Backend Integration

### Current Status: Mock Mode ✅
All API calls use placeholder functions that simulate real responses.

### To Connect Your Backend:

1. **Set environment variable** in `.env.local`:
   ```
   NEXT_PUBLIC_API_URL=https://your-backend-url.com
   ```

2. **Your backend should have these 3 endpoints:**

   **Endpoint 1: LLM Simplification**
   ```
   POST /api/llm
   Request: { content: string, contentType: "text" | "image" }
   Response: { simplifiedText: string, success: boolean }
   ```

   **Endpoint 2: OCR Classification**
   ```
   POST /api/ocr
   Request: { image: "base64_string" }
   Response: { 
     reactionClass: "normal" | "inattentive" | "hyperactive-impulsive" | "combined",
     reactionScore: number,
     confidence: number,
     success: boolean 
   }
   ```

   **Endpoint 3: GAN Personalization**
   ```
   POST /api/gan
   Request: { text: string, reactionClass: string, reactionScore: number }
   Response: { personalizedText: string, success: boolean }
   ```

3. **The API service will automatically route** to your backend - no code changes needed!

---

## File Structure

```
/app
  /page.tsx                    ← Main app orchestrator (3 steps)
  /layout.tsx                  ← Layout with StudyProvider
  /globals.css                 ← Tailwind + design tokens

/components
  /steps
    /Step1Input.tsx            ← Content upload + camera permission
    /Step2Result.tsx           ← Simplified text + auto camera capture
    /Step5Result.tsx           ← Dynamic personalized result
  
  /ProgressBar.tsx            ← Shows step progress (1/3, 2/3, 3/3)
  /FloatingElements.tsx       ← Animated background elements
  /ConfettiTrigger.tsx        ← Celebration animation

/context
  /StudyContext.tsx           ← Global state (text, image, reaction, etc)

/services
  /api.ts                     ← API client (connect your backend here)

/hooks
  /useCamera.ts               ← WebRTC camera access

/public
  ← Static assets
```

---

## Key Components Explained

### StudyContext
Stores all data across the 3-step workflow:
- `originalContent` - User's input (text or image)
- `simplifiedText` - Output from LLM
- `reactionImage` - Base64 image from auto-capture
- `reactionClass` - Classification from OCR
- `reactionScore` - Confidence from OCR
- `personalizedText` - Final content from GAN

### API Service (`services/api.ts`)
Three main functions you'll integrate:
- `simplifyContent(content, type)` → Calls `/api/llm`
- `classifyReaction(image)` → Calls `/api/ocr`
- `personalizeContent(text, reactionClass, score)` → Calls `/api/gan`

Mock versions with "_mock" prefix work without backend.

### Step 2: Auto-Capture Logic
```
ComponentMount
  ↓
RequestCameraPermission
  ↓
Start5SecondCountdown
  ↓
CaptureImageAutomatically
  ↓
CallOCRforClassification
  ↓
CallGANforPersonalization
  ↓
AutoTransitionToStep3
```

---

## Customization Options

### Colors & Theming
Edit `app/globals.css` to change:
- `--step-1-bg`, `--step-1-text` (pink input theme)
- `--step-2-bg`, `--step-2-text` (blue study theme)
- `--step-5-normal-bg`, `--step-5-inattentive-bg`, etc. (dynamic result themes)

### Reaction Classifications
Edit `Step2Result.tsx` and `Step5Result.tsx` to customize:
- Emoji for each reaction type
- Motivational messages
- UI styling per reaction class
- Suggested adjustments (font size, spacing, etc.)

### Animation Timing
- `Step2Result.tsx` line 31: Change countdown duration (currently 5 seconds)
- `services/api.ts`: Adjust mock API delays (simulate network lag)

### Text Content
All UI text can be customized in the respective component files. Search for strings like:
- "Here's the Simplified Version!" (Step 2 header)
- "Perfect Focus!" (Step 3 success message)
- etc.

---

## Testing Without Camera

If you want to test without a real camera:
1. Comment out `await startCamera()` in `Step2Result.tsx` line 30
2. The app will still capture a blank image
3. Reaction classification will still work with mock data

---

## Troubleshooting

### "Camera access denied" error
- Check browser camera permissions for localhost
- Try a different browser
- Ensure `https://` (or localhost) is used

### Mock API taking too long
- Edit `services/api.ts` and reduce the `setTimeout` delays
- Currently set to 1500-2000ms to simulate real API calls

### Images not being captured
- Ensure camera permission was granted in Step 1
- Check browser console for errors (F12 → Console)
- Verify `useCamera` hook in `hooks/useCamera.ts` is working

### Step not transitioning automatically
- Check console for errors
- Verify reaction classification succeeded
- Check that GAN response returned valid text

---

## Next Steps

1. ✅ Test the app locally with mock APIs
2. ✅ Verify camera capture and transitions work
3. Set up your backend endpoints for LLM, OCR, GAN
4. Update `NEXT_PUBLIC_API_URL` environment variable
5. Test with real backend endpoints
6. Deploy to production!

---

## Environment Variables

Create `.env.local` in project root:

```env
# Your backend API URL (optional - uses localhost:3001 by default)
NEXT_PUBLIC_API_URL=https://your-api.com

# Vercel Analytics (optional)
NEXT_PUBLIC_VERCEL_ANALYTICS_ID=your_id_here
```

---

## Support

For issues or questions:
- Check the console (F12) for detailed error messages
- Review `WORKFLOW_OVERVIEW.md` for detailed flow diagrams
- Review `API_INTEGRATION.md` for backend specifications
- Check component files for inline comments with [v0] prefix

Happy building! 🚀
