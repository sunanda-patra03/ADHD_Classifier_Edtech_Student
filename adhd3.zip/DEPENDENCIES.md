# Project Dependencies

## New Dependencies Added

The following packages were added to support the ADHD Student Support Web App:

### 1. **Framer Motion** (`framer-motion@^11.0.8`)
**Purpose:** Smooth animations and transitions
**Used In:**
- All step components for page transitions
- Button hover effects
- Loading spinners
- Floating background elements
- Confetti animation
**Why:** Creates engaging, performant animations without heavy CSS

**Installation:**
```bash
npm install framer-motion
```

**Example Usage:**
```typescript
import { motion } from 'framer-motion';

<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ delay: 0.1 }}
>
  Content
</motion.div>
```

---

### 2. **Axios** (`axios@^1.7.4`)
**Purpose:** HTTP client for API requests
**Used In:**
- `services/api.ts` for LLM, OCR, GAN calls
- All backend communication
**Why:** Cleaner than fetch, better error handling, request interceptors

**Installation:**
```bash
npm install axios
```

**Example Usage:**
```typescript
import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: 'https://api.example.com',
  timeout: 30000,
});

const response = await axiosInstance.post('/endpoint', data);
```

---

### 3. **canvas-confetti** (`canvas-confetti@^1.9.0`)
**Purpose:** Celebratory confetti animation on success
**Used In:**
- `components/ConfettiTrigger.tsx`
- Step 5 (Final result display)
**Why:** Gamified feedback to keep ADHD students engaged

**Installation:**
```bash
npm install canvas-confetti
```

**Example Usage:**
```typescript
import confetti from 'canvas-confetti';

confetti({
  particleCount: 100,
  spread: 70,
  colors: ['#fbbf24', '#f87171', '#60a5fa'],
});
```

---

### 4. **html2canvas** (`html2canvas@^1.4.1`)
**Purpose:** Convert HTML to canvas images (future use)
**Used In:**
- Reserved for screenshot/download functionality
**Why:** Allows saving/sharing personalized results

**Installation:**
```bash
npm install html2canvas
```

**Example Usage:**
```typescript
import html2canvas from 'html2canvas';

const canvas = await html2canvas(document.getElementById('result'));
const image = canvas.toDataURL('image/png');
// Save or download image
```

---

## Existing Dependencies (Already Installed)

### Core Framework
- **next** (16.x) - React framework
- **react** (19.x) - UI library
- **react-dom** (19.x) - DOM rendering

### Styling & UI
- **tailwindcss** (4.x) - Utility-first CSS
- **@radix-ui/** - Accessible component library
- Various shadcn/ui components

### Development
- **typescript** - Type safety
- **eslint** - Code linting
- **postcss** - CSS processing

### Analytics
- **@vercel/analytics** - Vercel Analytics integration

---

## Dependency Management

### Adding New Dependencies
```bash
# Using npm
npm install package-name

# Using pnpm (recommended)
pnpm add package-name

# Using yarn
yarn add package-name
```

### Updating Dependencies
```bash
# Update all
npm update

# Update specific package
npm install package@latest

# Check for outdated packages
npm outdated
```

### Removing Dependencies
```bash
npm uninstall package-name
```

---

## Version Constraints

The `package.json` uses semantic versioning:
- `^` (Caret) - Compatible minor versions
  - Example: `^1.7.4` allows `1.x.x` but not `2.0.0`
  - Used for: framer-motion, axios
  
- `~` (Tilde) - Compatible patch versions
  - Example: `~1.7.4` allows `1.7.x` but not `1.8.0`
  
- Exact versions - Locked to specific version
  - Example: `1.9.0` allows only `1.9.0`

### Current Dependency Versions
```json
{
  "axios": "^1.7.4",           // Allows 1.x.x
  "canvas-confetti": "^1.9.0", // Allows 1.x.x
  "framer-motion": "^11.0.8",  // Allows 11.x.x
  "html2canvas": "^1.4.1"      // Allows 1.x.x
}
```

---

## Bundle Size Impact

### Approximate Size (Gzipped)
- **framer-motion**: ~30 KB
- **axios**: ~5 KB
- **canvas-confetti**: ~15 KB
- **html2canvas**: ~55 KB
- **Total added**: ~105 KB

### Optimization Tips
1. **Code splitting** - Use dynamic imports for unused modules
2. **Tree shaking** - Remove unused code in build
3. **Lazy loading** - Load Step 5 only when needed
4. **Image optimization** - Compress captured camera images

---

## Browser Compatibility

All dependencies support modern browsers:

| Browser | Support |
|---------|---------|
| Chrome | ✅ Latest 2 versions |
| Firefox | ✅ Latest 2 versions |
| Safari | ✅ Latest 2 versions |
| Edge | ✅ Latest 2 versions |
| Mobile Safari | ✅ iOS 12+ |
| Chrome Mobile | ✅ Android 6+ |

**WebRTC Camera Support:**
- Chrome: ✅
- Firefox: ✅
- Safari: ✅ (iOS 14.5+)
- Edge: ✅

---

## Security Considerations

### Dependency Vulnerabilities
Check for security issues:
```bash
npm audit
npm audit fix
```

### Regular Updates
Keep dependencies updated for security patches:
```bash
npm update
```

### Trusted Sources
All dependencies are from npm registry and widely used:
- **framer-motion**: 10M+ weekly downloads, maintained by Framer
- **axios**: 30M+ weekly downloads, widely used in production
- **canvas-confetti**: 500K+ weekly downloads, popular animation library
- **html2canvas**: 3M+ weekly downloads, standard screenshot tool

---

## Node.js Version Requirements

Minimum Node.js version: **18.17.0**

```bash
# Check your Node version
node --version

# Update Node.js if needed
# Visit https://nodejs.org/
```

---

## Package Manager

This project uses **pnpm** (recommended) but also works with npm and yarn:

```bash
# Using pnpm (fastest)
pnpm install
pnpm run dev

# Using npm
npm install
npm run dev

# Using yarn
yarn install
yarn dev
```

**Why pnpm?**
- Faster installation
- Better disk space efficiency
- Strict dependency management
- Better monorepo support

---

## Environment Setup

### Install All Dependencies
```bash
pnpm install
# or: npm install
```

### Verify Installation
```bash
# Check if all packages installed correctly
pnpm list

# Check specific package
pnpm list framer-motion
```

### Clean Install (If Issues)
```bash
# Remove lock file
rm pnpm-lock.yaml
# or: rm package-lock.json

# Remove node_modules
rm -rf node_modules

# Fresh install
pnpm install
```

---

## Troubleshooting Dependencies

### Module Not Found
```bash
# Reinstall specific package
pnpm add framer-motion

# Or reinstall all
pnpm install
```

### Version Conflicts
```bash
# Check package version
pnpm list framer-motion

# Force update to specific version
pnpm add framer-motion@latest
```

### Build Errors
```bash
# Clear build cache
rm -rf .next

# Rebuild
pnpm run build
```

---

## Future Dependencies (Optional)

If you decide to add more features:

### For Backend Communication
- **swr** - Data fetching with caching
- **react-query** - Advanced data fetching
- **graphql-request** - GraphQL client

### For Form Handling
- **react-hook-form** - Lightweight form validation
- **zod** - TypeScript-first schema validation

### For State Management
- **zustand** - Lightweight state library
- **jotai** - Primitive atomic state management

### For Testing
- **jest** - Testing framework
- **@testing-library/react** - Component testing
- **vitest** - Fast unit test framework

### For Styling
- **styled-components** - CSS-in-JS (alternative to Tailwind)
- **emotion** - CSS-in-JS library

### For Monitoring
- **sentry** - Error tracking
- **logrocket** - Session replay and debugging

---

## Dependency Maintenance

### Weekly Tasks
- [ ] Check for security updates: `npm audit`
- [ ] Review error logs

### Monthly Tasks
- [ ] Update dependencies: `npm update`
- [ ] Review unused packages: `npm ls`
- [ ] Check bundle size impact

### Quarterly Tasks
- [ ] Major version upgrades if needed
- [ ] Performance profiling
- [ ] Dependency audit for deprecated packages

---

## References

- [npm Documentation](https://docs.npmjs.com/)
- [Node.js Documentation](https://nodejs.org/docs/)
- [pnpm Documentation](https://pnpm.io/)
- [Dependency Management Best Practices](https://snyk.io/blog/10-npm-security-best-practices/)

---

## Support

For dependency-related questions:
- Check official package documentation
- Search GitHub issues
- Review npm package page
- Ask in Next.js Discord community

All dependencies are production-ready and widely used in the ecosystem. ✅
