'use client';

import React, { createContext, useContext, useState, ReactNode } from 'react';

export type ReactionClass = 'normal' | 'inattentive' | 'hyperactive-impulsive' | 'combined' | null;

export interface StudyData {
  originalContent: string;
  originalContentType: 'text' | 'image' | null;
  simplifiedText: string;
  reactionImage: string | null;
  reactionClass: ReactionClass;
  reactionScore: number | null;
  personalizedText: string;
  currentStep: number;
}

interface StudyContextType {
  data: StudyData;
  setOriginalContent: (content: string, type: 'text' | 'image') => void;
  setSimplifiedText: (text: string) => void;
  setReactionImage: (image: string) => void;
  setReactionClass: (reactionClass: ReactionClass, score: number) => void;
  setPersonalizedText: (text: string) => void;
  setCurrentStep: (step: number) => void;
  reset: () => void;
}

const StudyContext = createContext<StudyContextType | undefined>(undefined);

const initialData: StudyData = {
  originalContent: '',
  originalContentType: null,
  simplifiedText: '',
  reactionImage: null,
  reactionClass: null,
  reactionScore: null,
  personalizedText: '',
  currentStep: 1,
};

export function StudyProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<StudyData>(initialData);

  const setOriginalContent = (content: string, type: 'text' | 'image') => {
    setData(prev => ({
      ...prev,
      originalContent: content,
      originalContentType: type,
    }));
  };

  const setSimplifiedText = (text: string) => {
    setData(prev => ({
      ...prev,
      simplifiedText: text,
    }));
  };

  const setReactionImage = (image: string) => {
    setData(prev => ({
      ...prev,
      reactionImage: image,
    }));
  };

  const setReactionClass = (reactionClass: ReactionClass, score: number) => {
    setData(prev => ({
      ...prev,
      reactionClass,
      reactionScore: score,
    }));
  };

  const setPersonalizedText = (text: string) => {
    setData(prev => ({
      ...prev,
      personalizedText: text,
    }));
  };

  const setCurrentStep = (step: number) => {
    setData(prev => ({
      ...prev,
      currentStep: step,
    }));
  };

  const reset = () => {
    setData(initialData);
  };

  const value: StudyContextType = {
    data,
    setOriginalContent,
    setSimplifiedText,
    setReactionImage,
    setReactionClass,
    setPersonalizedText,
    setCurrentStep,
    reset,
  };

  return (
    <StudyContext.Provider value={value}>
      {children}
    </StudyContext.Provider>
  );
}

export function useStudy() {
  const context = useContext(StudyContext);
  if (!context) {
    throw new Error('useStudy must be used within StudyProvider');
  }
  return context;
}
