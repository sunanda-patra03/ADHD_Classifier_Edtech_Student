import axios, { AxiosInstance } from 'axios';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001';

const axiosInstance: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

export interface SimplifyResponse {
  simplifiedText: string;
  success: boolean;
  error?: string;
}

export interface OCRResponse {
  reactionClass: 'normal' | 'inattentive' | 'hyperactive-impulsive' | 'combined';
  reactionScore: number;
  confidence: number;
  success: boolean;
  error?: string;
}

export interface ContinuousOCRResponse {
  currentClass: 'normal' | 'inattentive' | 'hyperactive-impulsive' | 'combined';
  currentScore: number;
  averageScore: number;
  frameCount: number;
  confidence: number;
  success: boolean;
}

export interface GANResponse {
  personalizedText: string;
  success: boolean;
  error?: string;
}

class APIService {
  /**
   * Send text or image to LLM for simplification
   * @param content - Text string or base64 image
   * @param contentType - 'text' or 'image'
   */
  async simplifyContent(content: string, contentType: 'text' | 'image'): Promise<SimplifyResponse> {
    try {
      console.log('[v0] Calling LLM simplify endpoint');
      const response = await axiosInstance.post('/api/llm', {
        content,
        contentType,
      });
      console.log('[v0] LLM response:', response.data);
      return response.data;
    } catch (error) {
      console.error('[v0] Error calling LLM:', error);
      throw new Error('Failed to simplify content. Please try again.');
    }
  }

  /**
   * Send reaction image to OCR for classification
   * @param imageData - Base64 encoded image
   */
  async classifyReaction(imageData: string): Promise<OCRResponse> {
    try {
      console.log('[v0] Calling OCR classify endpoint');
      const response = await axiosInstance.post('/api/ocr', {
        image: imageData,
      });
      console.log('[v0] OCR response:', response.data);
      return response.data;
    } catch (error) {
      console.error('[v0] Error calling OCR:', error);
      throw new Error('Failed to classify reaction. Please try again.');
    }
  }

  /**
   * Send continuous video frame to OCR for real-time classification
   * @param frameData - Base64 encoded frame
   */
  async analyzeVideoFrame(frameData: string): Promise<ContinuousOCRResponse> {
    try {
      const response = await axiosInstance.post('/api/ocr/video-frame', {
        frame: frameData,
      });
      return response.data;
    } catch (error) {
      console.error('[v0] Error analyzing video frame:', error);
      throw new Error('Failed to analyze video frame.');
    }
  }

  /**
   * Finalize continuous video analysis and get final reaction class
   */
  async finalizeVideoAnalysis(): Promise<OCRResponse> {
    try {
      console.log('[v0] Finalizing continuous video analysis');
      const response = await axiosInstance.post('/api/ocr/finalize', {});
      console.log('[v0] Final OCR response:', response.data);
      return response.data;
    } catch (error) {
      console.error('[v0] Error finalizing video analysis:', error);
      throw new Error('Failed to finalize reaction analysis.');
    }
  }

  /**
   * Send simplified text and reaction class to GAN for personalization
   * @param simplifiedText - The text from LLM
   * @param reactionClass - The reaction class from OCR
   * @param reactionScore - The score from OCR
   */
  async personalizeContent(
    simplifiedText: string,
    reactionClass: string,
    reactionScore: number
  ): Promise<GANResponse> {
    try {
      console.log('[v0] Calling GAN personalize endpoint');
      const response = await axiosInstance.post('/api/gan', {
        text: simplifiedText,
        reactionClass,
        reactionScore,
      });
      console.log('[v0] GAN response:', response.data);
      return response.data;
    } catch (error) {
      console.error('[v0] Error calling GAN:', error);
      throw new Error('Failed to personalize content. Please try again.');
    }
  }

  /**
   * Mock implementation for development/testing
   * Replace with real implementation by changing the endpoint
   */
  async mockSimplifyContent(content: string): Promise<SimplifyResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const mockSimplified = `Here's a simpler version of your content:

${content.substring(0, 100)}...

This has been simplified for easier understanding.`;

    return {
      simplifiedText: mockSimplified,
      success: true,
    };
  }

  async mockClassifyReaction(): Promise<OCRResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const reactions: Array<'normal' | 'inattentive' | 'hyperactive-impulsive' | 'combined'> = [
      'normal',
      'inattentive',
      'hyperactive-impulsive',
      'combined',
    ];
    const randomReaction = reactions[Math.floor(Math.random() * reactions.length)];

    return {
      reactionClass: randomReaction,
      reactionScore: Math.random() * 100,
      confidence: Math.random() * 100,
      success: true,
    };
  }

  async mockAnalyzeVideoFrame(): Promise<ContinuousOCRResponse> {
    // Simulate frame analysis delay
    await new Promise(resolve => setTimeout(resolve, 100));

    const reactions: Array<'normal' | 'inattentive' | 'hyperactive-impulsive' | 'combined'> = [
      'normal',
      'inattentive',
      'hyperactive-impulsive',
      'combined',
    ];
    const randomReaction = reactions[Math.floor(Math.random() * reactions.length)];

    return {
      currentClass: randomReaction,
      currentScore: Math.random() * 100,
      averageScore: Math.random() * 100,
      frameCount: Math.floor(Math.random() * 30) + 1,
      confidence: 70 + Math.random() * 30,
      success: true,
    };
  }

  async mockFinalizeVideoAnalysis(): Promise<OCRResponse> {
    // Simulate finalization delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const reactions: Array<'normal' | 'inattentive' | 'hyperactive-impulsive' | 'combined'> = [
      'normal',
      'inattentive',
      'hyperactive-impulsive',
      'combined',
    ];
    const randomReaction = reactions[Math.floor(Math.random() * reactions.length)];

    return {
      reactionClass: randomReaction,
      reactionScore: 70 + Math.random() * 30,
      confidence: 75 + Math.random() * 25,
      success: true,
    };
  }

  async mockPersonalizeContent(simplifiedText: string, reactionClass?: string): Promise<GANResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Create personalized content based on reaction class
    let adaptedText = simplifiedText;
    
    if (reactionClass === 'inattentive') {
      adaptedText = `🎯 SIMPLIFIED FOR YOU 🎯\n\n${simplifiedText}\n\n💡 Key Points:\n• Take it one step at a time\n• Focus on the main ideas\n• Short, clear sentences\n\n✨ You can learn this!`;
    } else if (reactionClass === 'hyperactive-impulsive') {
      adaptedText = `⚡ ENERGIZED VERSION ⚡\n\n${simplifiedText}\n\n🚀 ACTION ITEMS:\n→ Jump in and explore!\n→ Try hands-on learning\n→ Keep the momentum going!\n\n💪 Channel that energy!`;
    } else if (reactionClass === 'combined') {
      adaptedText = `🎯 BALANCED APPROACH 🎯\n\n${simplifiedText}\n\n📚 Mix & Match:\n• Mix theory with practice\n• Break into chunks\n• Add variety to stay engaged\n\n⭐ Your unique style rocks!`;
    } else {
      adaptedText = `✨ OPTIMIZED FOR YOU ✨\n\n${simplifiedText}\n\n📖 Learning Tips:\n• You're in your sweet spot\n• Keep this pace going\n• You've got a great grasp on this\n\n🎉 Keep it up!`;
    }

    return {
      personalizedText: adaptedText,
      success: true,
    };
  }
}

export const apiService = new APIService();
