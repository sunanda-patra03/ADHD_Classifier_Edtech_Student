'use client';

import { useRef, useState, useCallback } from 'react';

export function useCamera() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isActive, setIsActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const frameIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const startCamera = useCallback(async () => {
    try {
      console.log('[v0] Requesting camera access');
      setError(null);
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user',
        },
        audio: false,
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsActive(true);
        console.log('[v0] Camera started successfully');
      }
    } catch (err) {
      console.error('[v0] Camera error:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to access camera';
      setError(errorMessage);
      setIsActive(false);
    }
  }, []);

  const stopCamera = useCallback(() => {
    console.log('[v0] Stopping camera');
    if (frameIntervalRef.current) {
      clearInterval(frameIntervalRef.current);
      frameIntervalRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsActive(false);
  }, []);

  const captureImage = useCallback((): string | null => {
    if (!videoRef.current || !canvasRef.current) {
      setError('Video or canvas reference not found');
      return null;
    }

    try {
      const context = canvasRef.current.getContext('2d');
      if (!context) {
        setError('Failed to get canvas context');
        return null;
      }

      // Set canvas dimensions to match video
      canvasRef.current.width = videoRef.current.videoWidth;
      canvasRef.current.height = videoRef.current.videoHeight;

      // Draw video frame to canvas
      context.drawImage(
        videoRef.current,
        0,
        0,
        canvasRef.current.width,
        canvasRef.current.height
      );

      // Convert to base64
      const imageData = canvasRef.current.toDataURL('image/jpeg', 0.9);
      return imageData;
    } catch (err) {
      console.error('[v0] Error capturing frame:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to capture frame';
      setError(errorMessage);
      return null;
    }
  }, []);

  const startContinuousCapture = useCallback((callback: (frameData: string) => void, intervalMs: number = 1000) => {
    console.log('[v0] Starting continuous frame capture at', intervalMs, 'ms intervals');
    frameIntervalRef.current = setInterval(() => {
      const frameData = captureImage();
      if (frameData) {
        callback(frameData);
      }
    }, intervalMs);
  }, [captureImage]);

  const stopContinuousCapture = useCallback(() => {
    console.log('[v0] Stopping continuous frame capture');
    if (frameIntervalRef.current) {
      clearInterval(frameIntervalRef.current);
      frameIntervalRef.current = null;
    }
  }, []);

  return {
    videoRef,
    canvasRef,
    isActive,
    error,
    startCamera,
    stopCamera,
    captureImage,
    startContinuousCapture,
    stopContinuousCapture,
  };
}
