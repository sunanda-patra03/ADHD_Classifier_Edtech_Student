# Customization Guide - ADHD Student Support App

This guide explains how to customize the app's behavior, appearance, and response handling to match your specific needs.

---

## 1. Customizing Reaction Classifications

### Where to Change
- **Step5Result.tsx** (Final result display)
- **services/api.ts** (Mock response structure)

### Current Reaction Types
```
normal: Balanced, focused learning
inattentive: Difficulty maintaining focus, needs simplification
hyperactive-impulsive: High energy, difficulty with long content
combined: Mix of both inattentive and hyperactive symptoms
```

### To Add New Reaction Types
1. Update `StudyContext.tsx` - Add to `ReactionClass` type:
   ```typescript
   export type ReactionClass = 'normal' | 'inattentive' | 'hyperactive-impulsive' | 'combined' | 'anxious';
   ```

2. Update `services/api.ts` - Add to mock response:
   ```typescript
   const reactions: Array<...> = [
     'normal',
     'inattentive',
     'hyperactive-impulsive',
     'combined',
     'anxious'  // NEW
   ];
   ```

3. Update `Step5Result.tsx` - Add theme config:
   ```typescript
   anxious: {
     bg: 'from-purple-100 to-purple-50',
     border: 'border-purple-400',
     header: 'text-purple-800',
     message: 'bg-purple-100 border-purple-400 text-purple-800',
     button: 'from-purple-400 to-purple-500',
     emoji: '😰',
     title: 'Breathe & Focus!',
   }
   ```

4. Update OCR response to include new classification from your backend

---

## 2. Customizing Content Adaptation

### GAN Response Structure
The app currently displays personalized text in a placeholder structure. Your GAN model should return:

```json
{
  "personalizedText": "The adapted content here...",
  "success": true
}
```

### Extending Response Data
To include more GAN metadata (currently ignored):

**In services/api.ts:**
```typescript
export interface GANResponse {
  personalizedText: string;
  success: boolean;
  styleAdjustments?: {
    fontSize?: 'small' | 'normal' | 'large' | 'extra-large';
    spacing?: 'compact' | 'normal' | 'generous';
    complexity?: 'simplified' | 'moderate' | 'advanced';
    format?: 'bullet-points' | 'paragraphs' | 'interactive';
  };
  additionalResources?: string[];
  error?: string;
}
```

**In Step2Result.tsx**, handle additional data:
```typescript
if (ganResponse.styleAdjustments) {
  // Store or use style adjustments
  console.log('[v0] Style adjustments:', ganResponse.styleAdjustments);
}
```

**In Step5Result.tsx**, display additional resources:
```typescript
{ganResponse.additionalResources && (
  <div className="mt-6">
    <h3>Recommended Resources:</h3>
    {ganResponse.additionalResources.map(resource => (
      <a key={resource} href={resource}>{resource}</a>
    ))}
  </div>
)}
```

---

## 3. Customizing UI Colors & Themes

### Design Tokens in globals.css
All colors are defined as CSS variables in `app/globals.css`:

```css
:root {
  /* Step-specific background colors */
  --step-1-bg: oklch(0.92 0.16 310);  /* Pink */
  --step-2-bg: oklch(0.88 0.18 240);  /* Blue */
  
  /* Reaction-based result colors */
  --step-5-normal-bg: oklch(0.90 0.15 130);      /* Green */
  --step-5-inattentive-bg: oklch(0.92 0.16 60); /* Orange */
  --step-5-hyperactive-bg: oklch(0.88 0.18 30); /* Red */
  --step-5-combined-bg: oklch(0.85 0.18 280);   /* Purple */
}
```

### To Change Colors
1. Find the token in `globals.css`
2. Modify the OKLch value (format: `oklch(lightness saturation hue)`)
3. Use [oklch color picker](https://oklch.com/) to find colors

### To Use Different Color Format
Replace OKLch with your preferred format in both `globals.css` and component files:

```css
/* Option 1: Hex */
--step-1-bg: #ffc0e0;

/* Option 2: RGB */
--step-1-bg: rgb(255, 192, 224);

/* Option 3: HSL */
--step-1-bg: hsl(320, 100%, 88%);
```

### Step Themes (Quick Reference)
- **Step 1 (Input)**: Pink - `--step-1-bg`, `--step-1-text`
- **Step 2 (Study)**: Blue - `--step-2-bg`, `--step-2-text`
- **Step 3 Results**: Dynamic based on reaction class

---

## 4. Customizing UI Text & Messages

### Step-by-Step Text Customization

**Step 1 (Input Screen)**
- File: `components/steps/Step1Input.tsx`
- Search for strings like:
  - `"Upload Content"` → Header
  - `"Type your content..."` → Textarea placeholder
  - `"Submit & Start Learning"` → Button text

**Step 2 (Study + Capture)**
- File: `components/steps/Step2Result.tsx`
- Search for strings like:
  - `"Here's the Simplified Version!"` → Header
  - `"Just relax and keep reading! 📸"` → Countdown message
  - `"Analyzing your reaction..."` → Processing message

**Step 3 (Results)**
- File: `components/steps/Step5Result.tsx`
- Search for reaction-specific messages:
  ```typescript
  const theme = {
    normal: {
      title: 'You\'re Focused & Ready!',  // ← Change this
      // ...
    }
  }
  ```
- Success messages in motivational message section

### Adding Translations
To support multiple languages, wrap text in translation function:

```typescript
// In component:
<h1>{t('step1.header')}</h1>

// Create translation file: /public/locales/en.json
{
  "step1": {
    "header": "Upload Content"
  }
}

// Add i18n library like next-i18next
```

---

## 5. Customizing Animations

### Framer Motion Timing
Adjust animation speeds in component files:

```typescript
// In Step1Input.tsx
<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ delay: 0.1, duration: 0.5 }}  // ← Adjust duration
>
```

### Auto-Capture Countdown
In `Step2Result.tsx` line 43:
```typescript
captureTimeout = setTimeout(() => {
  handleAutoCaptureAndClassify();
}, 5000);  // ← Change from 5000ms to desired duration
```

### Confetti Animation
In `ConfettiTrigger.tsx`:
```typescript
confetti({
  particleCount: 100,   // ← More particles = more confetti
  spread: 70,           // ← Wider spread = more spread out
  origin: { x: 0.5, y: 0.5 },
  colors: [/* colors */],  // ← Add/remove colors
});
```

---

## 6. Customizing Camera Behavior

### Camera Permission Handling
In `components/steps/Step1Input.tsx`:

```typescript
const requestCameraPermission = async () => {
  try {
    // Customize constraints if needed
    await navigator.mediaDevices.getUserMedia({
      video: {
        width: { ideal: 1280 },      // ← Adjust resolution
        height: { ideal: 720 },
        facingMode: 'user'           // ← 'user' or 'environment'
      }
    });
    return true;
  } catch (err) {
    // Custom error handling
  }
};
```

### Auto-Capture Image Quality
In `hooks/useCamera.ts`:

```typescript
const captureImage = (): string | null => {
  if (!canvasRef.current || !videoRef.current) return null;
  
  const ctx = canvasRef.current.getContext('2d');
  ctx?.drawImage(videoRef.current, 0, 0);
  
  // Change image format
  return canvasRef.current.toDataURL('image/jpeg', 0.9);  // ← Adjust quality (0-1)
};
```

### Disable Camera (For Testing)
Comment out in `Step2Result.tsx` line 30:
```typescript
// await startCamera();  // Disables camera for testing
```

---

## 7. Customizing Backend Integration

### Switching Between Mock & Real APIs
The app automatically uses real APIs if `NEXT_PUBLIC_API_URL` is set.

**For Development (Mock):**
```
NEXT_PUBLIC_API_URL=  # Leave empty or unset
```

**For Production (Real):**
```
NEXT_PUBLIC_API_URL=https://your-backend.com
```

### Customizing Mock Response Delays
In `services/api.ts`, adjust timeout to simulate network lag:

```typescript
async mockSimplifyContent() {
  await new Promise(resolve => setTimeout(resolve, 1500));  // ← Adjust delay
  // ...
}
```

### Custom Error Handling
Wrap API calls with error handling:

```typescript
try {
  const response = await apiService.simplifyContent(content, type);
  if (!response.success) {
    showErrorMessage(response.error || 'Unknown error');
  }
} catch (error) {
  console.error('Custom error handling:', error);
  // Show user-friendly message
}
```

---

## 8. Customizing Learning Style Adjustments

### Style Suggestions Display
In `Step5Result.tsx`, show adaptive styling:

```typescript
<div className="mt-6 p-4 bg-blue-50 rounded-lg">
  <h3>Personalized Learning Adjustments:</h3>
  <ul>
    <li>Font Size: {ganJsonResponse.styleAdjustments.fontSize}</li>
    <li>Spacing: {ganJsonResponse.styleAdjustments.spacing}</li>
    <li>Complexity: {ganJsonResponse.styleAdjustments.complexity}</li>
  </ul>
</div>
```

### Apply Styling Directly
Apply returned style adjustments to content display:

```typescript
const getContentClassName = (styleAdjustments: any) => {
  const fontSizeMap = {
    'larger': 'text-3xl',
    'medium': 'text-2xl',
    'normal': 'text-xl',
    'small': 'text-lg',
  };
  
  const spacingMap = {
    'generous': 'leading-loose gap-6',
    'normal': 'leading-relaxed gap-4',
    'compact': 'leading-tight gap-2',
  };
  
  return `${fontSizeMap[styleAdjustments.fontSize]} ${spacingMap[styleAdjustments.spacing]}`;
};
```

---

## 9. Performance Optimizations

### Image Compression
Compress captured images before sending to OCR:

```typescript
// In Step2Result.tsx
const compressImage = (imageData: string) => {
  // Use canvas to re-encode at lower quality
  const img = new Image();
  img.src = imageData;
  img.onload = () => {
    const canvas = document.createElement('canvas');
    canvas.width = img.width * 0.5;  // ← 50% scale
    canvas.height = img.height * 0.5;
    const ctx = canvas.getContext('2d');
    ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.7);  // ← 70% quality
  };
};
```

### Lazy Loading Components
Use React.lazy for unused components:

```typescript
const Step4Processing = lazy(() => 
  import('@/components/steps/Step4Processing').then(m => ({ 
    default: m.Step4Processing 
  }))
);
```

---

## 10. Accessibility Improvements

### ARIA Labels
Add screen reader support:

```typescript
<button
  aria-label="Submit content for simplification"
  aria-describedby="submit-help"
>
  Submit & Start Learning
</button>
<p id="submit-help" className="sr-only">
  Click to send your content to be simplified
</p>
```

### Keyboard Navigation
Ensure all interactive elements are keyboard accessible:

```typescript
<button
  onKeyDown={(e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      handleSubmit();
    }
  }}
>
  Submit
</button>
```

### Color Contrast
Verify text/background contrast meets WCAG AA standards (4.5:1 minimum for normal text).

---

## Quick Customization Checklist

- [ ] Update step titles and messages
- [ ] Adjust color palette in `globals.css`
- [ ] Customize reaction type names and themes
- [ ] Adjust animation timings
- [ ] Test camera permissions
- [ ] Set up backend API endpoints
- [ ] Test with real vs mock APIs
- [ ] Add translations (if needed)
- [ ] Test accessibility with screen readers
- [ ] Performance test with large images

---

## Need Help?

Check these files for implementation details:
- **State Management**: `context/StudyContext.tsx`
- **API Client**: `services/api.ts`
- **Component Structure**: Each file in `components/steps/`
- **Styling**: `app/globals.css`
- **Hooks**: `hooks/useCamera.ts`
