# ADHD Student Support Web App

An interactive, ADHD-friendly web application that helps students understand complex content by simplifying it and personalizing it based on their learning style and reaction patterns.

## Features

- **5-Step Workflow**: Simple, guided process from content input to personalized results
- **ADHD-Optimized UI**: 
  - Pastel color palettes that change with each step
  - Large, readable fonts
  - Generous spacing
  - Smooth animations and transitions
  - Engaging floating elements
- **Dynamic Content**: Uses AI/ML to simplify complex content
- **Reaction Classification**: Captures and analyzes student reactions (normal, inattentive, hyperactive-impulsive, combined)
- **Personalized Results**: GAN-powered content adaptation based on reaction type
- **Interactive Gamification**: Confetti effects, progress tracking, and motivating feedback
- **Full Web-Based**: Works in modern browsers without mobile-specific constraints

## Tech Stack

- **Frontend**: React 19, Next.js 16, TypeScript
- **Styling**: Tailwind CSS with custom ADHD-friendly color palette
- **Animations**: Framer Motion
- **State Management**: React Context API
- **HTTP Client**: Axios
- **Media**: WebRTC for camera access
- **Visual Effects**: canvas-confetti

## Getting Started

### Prerequisites

- Node.js 18+ and npm/pnpm
- A backend service with LLM, OCR, and GAN endpoints (see [API_INTEGRATION.md](API_INTEGRATION.md))

### Installation

1. **Clone or download the project**

2. **Install dependencies**:
   ```bash
   npm install
   # or
   pnpm install
   ```

3. **Create `.env.local` file**:
   ```bash
   cp .env.example .env.local
   ```

4. **Update `.env.local` with your API URL**:
   ```
   NEXT_PUBLIC_API_URL=http://localhost:3001
   ```

### Running Locally

```bash
npm run dev
# or
pnpm dev
```

Visit `http://localhost:3000` in your browser.

## Project Structure

```
/vercel/share/v0-project/
├── app/
│   ├── layout.tsx          # Root layout with StudyProvider
│   ├── page.tsx            # Main app page orchestrating all steps
│   └── globals.css         # Global styles and design tokens
├── components/
│   ├── ui/                 # shadcn/ui components
│   ├── ProgressBar.tsx     # Step progress indicator
│   ├── FloatingElements.tsx # Animated background elements
│   ├── ConfettiTrigger.tsx # Celebration animation
│   └── steps/
│       ├── Step1Input.tsx      # Text/image upload
│       ├── Step2Result.tsx     # Simplified content display
│       ├── Step3Camera.tsx     # Camera capture
│       ├── Step4Processing.tsx # Loading/processing screen
│       └── Step5Result.tsx     # Final personalized result
├── context/
│   └── StudyContext.tsx    # Global state management
├── hooks/
│   └── useCamera.ts        # WebRTC camera hook
├── services/
│   └── api.ts              # API client with mock functions
└── public/                 # Static assets

```

## How to Use

1. **Start**: User uploads text or an image
2. **Simplify**: Content is sent to LLM for simplification
3. **Capture**: Camera captures the student's reaction
4. **Analyze**: OCR classifies the reaction (4 classes)
5. **Personalize**: GAN adapts the simplified text based on reaction
6. **Display**: Result shown with theme matching reaction type

## API Integration

The app expects three API endpoints from your backend:

1. **POST `/api/llm`** - Simplifies content
2. **POST `/api/ocr`** - Classifies reaction from image
3. **POST `/api/gan`** - Personalizes text based on reaction

See [API_INTEGRATION.md](API_INTEGRATION.md) for detailed specifications and examples.

## Customization

### Changing Colors

Edit the design tokens in `app/globals.css` under `:root`:

```css
:root {
  /* Step-specific colors */
  --step-1-bg: oklch(0.92 0.16 310);     /* Pink theme */
  --step-2-bg: oklch(0.88 0.18 240);     /* Blue theme */
  --step-3-bg: oklch(0.92 0.16 60);      /* Yellow theme */
  --step-4-bg: oklch(0.85 0.18 280);     /* Purple theme */
  /* ... and more */
}
```

### Adding New Reaction Classes

Update the `ReactionClass` type in `context/StudyContext.tsx` and add corresponding themes in `components/steps/Step5Result.tsx`.

### Customizing Content

Replace mock API calls in `services/api.ts` with real implementations, or modify the mock functions for testing.

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Requires camera permissions for Step 3

## Debugging

Debug messages are logged with `[v0]` prefix in the browser console:

```
[v0] Calling LLM simplify endpoint
[v0] LLM response: {...}
[v0] Step 1: Submitting content
```

## Known Limitations

- Camera requires HTTPS in production
- Large images may take time to process
- Mobile browsers have varying WebRTC support

## Future Enhancements

- [ ] Offline support with service workers
- [ ] Sound effects and audio cues
- [ ] Progress saving and history
- [ ] Accessibility improvements (ARIA labels)
- [ ] Multiple language support
- [ ] Keyboard navigation enhancements

## Contributing

Contributions are welcome! Areas for improvement:

- More reaction classes/emotions
- Additional animation effects
- Theme customization UI
- Performance optimization
- Mobile responsiveness enhancements

## License

This project is open source and available for educational use.

## Support

For issues, questions, or feature requests:

1. Check the [API_INTEGRATION.md](API_INTEGRATION.md) guide
2. Review the browser console for debug logs
3. Verify API endpoints are working correctly
4. Check `.env.local` configuration

---

**Built with care for ADHD students everywhere** ✨
