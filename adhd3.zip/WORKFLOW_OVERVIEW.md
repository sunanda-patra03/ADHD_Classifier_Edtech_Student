# ADHD Student Support Web App - Workflow Overview

## Updated 3-Step Workflow

The application has been restructured for a seamless, automatic learning experience where students upload content and see personalized results without interruption.

### Step 1: Content Input (Pink Theme)
**What Happens:**
- Student uploads text OR image content
- Camera permission is requested and obtained before proceeding
- Simple toggle between text typing and image upload
- Clear, large UI with minimal friction

**User Actions:**
- Choose input mode (text or image)
- Type text OR select image file
- Click "Submit & Start Learning"

**Backend Integration:**
- Content sent to your LLM (`/api/llm` endpoint)
- LLM simplifies the content to JSON format
- Returns `simplifiedText` for next step

---

### Step 2: Simultaneous Study + Continuous Reaction Analysis (Blue Theme)
**What Happens:**
- Simplified content is displayed on left side
- **Live camera feed streams continuously on right side**
- **Real-time reaction analysis**: OCR processes video frames every 1 second while student reads
- Live reaction class and confidence score displayed and updated in real-time
- Study duration and frame count tracked
- No manual captures - completely passive and continuous
- Captures happen in background while student reads/studies

**Key Features:**
- Large, readable simplified text on left
- Live camera feed displayed on right in real-time
- Reaction metrics updated every frame (frames captured, study time, reaction class, confidence score)
- Student controls study duration - clicks "Done Reading" when finished
- LIVE indicator shows camera is actively streaming and analyzing

**Processing Flow (Real-time):**
1. Video stream starts and frames continuously captured (~1 second intervals)
2. Each frame sent to OCR (`/api/ocr/video-frame`) for live classification
3. OCR returns live `reactionClass` and `reactionScore` for each frame
4. UI updates in real-time with reaction data and progress
5. When "Done Reading" clicked:
   - `/api/ocr/finalize` called to get final classification (aggregate of all frames)
   - Final reaction class sent to GAN (`/api/gan`) with simplified text
   - GAN returns personalized/adapted text based on overall student reaction type

**Student Sees:**
- Simplified content to read at own pace
- Live camera feed with LIVE indicator
- Real-time reaction class (updates as you read)
- Reaction confidence progress bar (0-100%)
- Frame and time counters
- "Done Reading" button to finish and get personalized result

---

### Step 3: Dynamic Personalized Result (Reaction-Based Theme)
**What Happens:**
- Final personalized content from GAN is displayed
- UI theme and styling change dynamically based on reaction class:
  - **Normal**: Green theme (😊) - "Perfect Focus!"
  - **Inattentive**: Amber/Orange theme (🤔) - "Take Your Time"
  - **Hyperactive-Impulsive**: Red theme (⚡) - "Full Speed Ahead!"
  - **Combined**: Indigo/Purple theme (🎯) - "Mixed Mode"

**Dynamic Styling Adjustments:**
- Font sizes adjusted based on reaction type
- Spacing and layout adapt to student needs
- Color scheme shifts to match learning style
- Motivational messages tailored to response

**Student Sees:**
- Original simplified content box
- Personalized adapted content box (larger, styled)
- Reaction classification and confidence score
- Three info cards: Learning Style, Confidence Level, Content Match
- Motivational message specific to their reaction type
- Celebratory confetti animation on success
- "Try Another Topic" and "View Details" buttons

---

## Backend Integration Points

### 1. Step 1 → LLM Simplification
**Endpoint:** `POST /api/llm`
```
Request:
{
  "content": "string (text or base64 image)",
  "contentType": "text" | "image"
}

Response:
{
  "simplifiedText": "string",
  "success": boolean,
  "error": "string (if failed)"
}
```

### 2. Step 2 → OCR Classification
**Endpoint:** `POST /api/ocr`
```
Request:
{
  "image": "base64 encoded image"
}

Response:
{
  "reactionClass": "normal" | "inattentive" | "hyperactive-impulsive" | "combined",
  "reactionScore": number (0-1 or 0-100),
  "confidence": number,
  "success": boolean,
  "error": "string (if failed)"
}
```

### 3. Step 2 → GAN Personalization
**Endpoint:** `POST /api/gan`
```
Request:
{
  "text": "simplified text from LLM",
  "reactionClass": "string from OCR",
  "reactionScore": number from OCR
}

Response:
{
  "personalizedText": "string (adapted content)",
  "success": boolean,
  "error": "string (if failed)"
}
```

---

## Technology Stack

- **Frontend:** Next.js 16 + React 19
- **Styling:** Tailwind CSS v4 with custom design tokens
- **Animations:** Framer Motion for smooth transitions
- **Camera:** WebRTC API (native browser)
- **HTTP Client:** Axios
- **Gamification:** canvas-confetti for celebration effects
- **State Management:** React Context API
- **Responsive:** Full web app (desktop-optimized, responsive layout)

---

## Current Implementation

### Mock/Development Mode
All API calls use mock functions by default:
- `mockSimplifyContent()` - Returns simplified placeholder text
- `mockClassifyReaction()` - Returns random reaction class
- `mockPersonalizeContent()` - Returns GAN-adapted text based on reaction class

### Production Mode
Replace mock calls with real endpoints by:
1. Setting `NEXT_PUBLIC_API_URL` environment variable to your backend URL
2. The API service will automatically route requests to your backend
3. No code changes needed - same function signatures work with both mock and real APIs

---

## User Experience Flow

```
┌─────────────────────────────────────────┐
│  Step 1: Upload Content                 │
│  (Pink Theme - Simple Input)            │
│  • Choose text or image                  │
│  • Request camera permission            │
│  → Send to LLM                          │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│  Step 2: Read & Capture (Simultaneous)  │
│  (Blue Theme - Active Study)            │
│  • Display simplified text              │
│  • Auto-capture reaction (5 sec)        │
│  → Send to OCR for classification       │
│  → Send to GAN for personalization      │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│  Step 3: Personalized Result            │
│  (Dynamic Theme - Based on Reaction)    │
│  • Display personalized content         │
│  • Show reaction classification         │
│  • Adaptive styling & motivation        │
│  • Confetti celebration! 🎉            │
│  • Try another or view details          │
└─────────────────────────────────────────┘
```

---

## Key Features

✅ **Automatic Camera Capture** - No manual clicking, just read and be captured
✅ **Seamless Workflow** - Each step flows into the next automatically
✅ **Dynamic Theming** - Colors and styling adapt to student reaction
✅ **ADHD-Friendly** - Large fonts, generous spacing, minimal distractions
✅ **Smooth Animations** - Framer Motion transitions keep engagement high
✅ **Gamified** - Confetti, emojis, celebratory messages for motivation
✅ **Production Ready** - Easy backend integration via API service layer
✅ **Mock Support** - Test without backend using mock functions

---

## Next Steps for Integration

1. **Update `.env.local`** with your backend URL:
   ```
   NEXT_PUBLIC_API_URL=https://your-backend.com
   ```

2. **Implement your real endpoints:**
   - `/api/llm` - Text/image simplification
   - `/api/ocr` - Reaction classification
   - `/api/gan` - Content personalization

3. **Test with mock first**, then swap endpoint in `services/api.ts`

4. **Customize response handling** if needed (error messages, timeout logic, etc.)

---

## Testing the App

With mock APIs enabled, you can:
- Upload sample text or test image
- See automatic 5-second countdown
- Get random reaction classification
- View dynamically themed personalized result
- Click "Try Another Topic" to reset and try again

All processing happens automatically with smooth transitions and engaging animations throughout.
